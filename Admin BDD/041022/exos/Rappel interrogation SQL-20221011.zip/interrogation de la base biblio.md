# interrogation de la base biblio

1. Sélectionnez tous les adhérents qui ont pour prénom 'Abel' 

```sql

```

2. Combien de fois a été emprunté le livre dont l'id est 15 ? 

```sql

```

3. Combien de fois a été rendu le livre dont l'id est 15 ?

```sql

```

4. Quel est le nombre de d'adhérents ?

```sql

```

5. Combien de livres contient la bibliothèque ?

```sql

```

6. Quels sont les livres qui n'ont pas d'auteur ?

```sql

```

7. Quels sont les livres qui ont plus d'un auteur ?

```sql

```

8. Quels sont les livres qui n'ont jamais été empruntés ?

```sql

```

9.  Quels sont les livres en cours d'emprunt ?

```sql

```

10. Quels sont les livres en cours d'emprunt et en retard ?

```sql

```

11. Afficher pour chaque livre le nombre d'exemplaires disponibles ?

```sql

```

12. Afficher les id des adhérents et leur nombre d'emprunts ayant fait plus de 5 emprunts après le 01/07/2017

```sql
```

13. Le nom de l'auteur le plus emprunté 

```sql

```

